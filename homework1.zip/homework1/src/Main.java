public class Main {

    public static void main(String[] args) {
        String nameDog;

        final int NUM = 10;

        String word = "250";
        nameDog = NUM + word;

        System.out.println(nameDog);

        if (NUM < 0){
            System.out.println("number < 0");
        }
        else if (NUM > 0) {
            System.out.println("number > 0");
        }
        else{
            System.out.println("0");
        }


    }
}

